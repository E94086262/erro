import pygame
import os
import math

TOWER_IMAGE = pygame.image.load(os.path.join("images", "rapid_test.png"))


class Circle:
    def __init__(self, center, radius):
        self.center = center
        self.radius = radius

    def collide(self, enemy):
        """
        Q2.2)check whether the enemy is in the circle (attack range), if the enemy is in range return True
        :param enemy: Enemy() object
        :return: Bool
        """

        """
        Hint:
        x1, y1 = enemy.get_pos()
        ...
        """
        x1, y1 = enemy.get_pos() #
        distance_center=math.sqrt(( x1- self.center[0]) ** 2 + (y1 - self.center[1]) ** 2)
        if(distance_center < self.radius):
            return True
        else:
            return False

    def draw_transparent(self, win):
        """
        Q1) draw the tower effect range, which is a transparent circle.
        :param win: window surface
        :return: None
        """
        transparent_surface = pygame.Surface((self.radius*2, self.radius*2), pygame.SRCALPHA) #用來裝圓的surface
        transparency=120 #透明度
        # define transparency: 0~255, 0 is fully transparent
        # draw circle on the transparent surface
        #畫圓
        pygame.draw.circle(transparent_surface, (128, 128, 128,transparency),(self.radius,self.radius),self.radius)
        win.blit(transparent_surface, (self.center[0]-self.radius,self.center[1]-self.radius))
        pass


class Tower:
    def __init__(self, x, y):
        self.image = pygame.transform.scale(TOWER_IMAGE, (70, 70))  # image of the tower
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)  # center of the tower
        self.range = 150  # tower attack range
        self.damage = 2   # tower damage
        self.range_circle = Circle(self.rect.center, self.range)  # attack range circle (class Circle())
        self.cd_count = 0  # 使用函數is_cool_down的次數
        self.cd_max_count = 60  # 攻擊冷卻一次的週期
        self.is_selected = True  # the state of whether the tower is selected
        self.type = "tower"

    def is_cool_down(self):
        """
        Q2.1) Return whether the tower is cooling down
        (1) Use a counter to computer whether the tower is cooling down (( self.cd_count
        :return: Bool
        """

        """
        Hint:
        let counter be 0
        if the counter < max counter then
            set counter to counter + 1
        else 
            counter return to zero
        end if
        """
        if(self.cd_count<self.cd_max_count): #攻擊冷卻中，self.cd_count 小於 週期(60次)
            self.cd_count+=1
            return True
        else: #攻擊冷卻完，將次數重新設為零，這樣才能重新下一波攻擊冷卻
            self.cd_count=0
            return False


    def attack(self, enemy_group):
        """
        Q2.3) Attack the enemy.
        (1) check the the tower is cool down ((self.is_cool_down()
        (2) if the enemy is in attack range, then enemy get hurt. ((Circle.collide(), enemy.get_hurt()
        :param enemy_group: EnemyGroup()
        :return: None
        """
        if not self.is_cool_down(): #攻擊要在沒有被冷卻的情況下，根據前面攻擊冷卻的設定，要在為False時，才沒有被冷卻
            for a in enemy_group.get(): #設定變數a，使用for迴圈讀取裝敵人的串列(從class Enemy_Group裡的get函數取得)
                if self.range_circle.collide(a): #判斷敵人是否在攻擊範圍內
                    a.get_hurt(self.damage) #讓敵人被扣血
                    break #使用break是為了讓防禦塔只能先攻擊最前面的敵人
    def is_clicked(self, x, y):
        """
        Bonus) Return whether the tower is clicked
        (1) If the mouse position is on the tower image, return True
        :param x: mouse pos x
        :param y: mouse pos y
        :return: Bool
        """
        pass

    def get_selected(self, is_selected):
        """
        Bonus) Change the attribute self.is_selected
        :param is_selected: Bool
        :return: None
        """
        self.is_selected = is_selected

    def draw(self, win):
        """
        Draw the tower and the range circle
        :param win:
        :return:
        """
        # draw range circle
        if self.is_selected:
            self.range_circle.draw_transparent(win)
        # draw tower
        win.blit(self.image, self.rect)


class TowerGroup:
    def __init__(self):
        self.constructed_tower = [Tower(250, 380), Tower(420, 400), Tower(600, 400)]

    def get(self):
        return self.constructed_tower

